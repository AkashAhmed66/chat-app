export interface User {
  id: string;
  username: string;
  displayName: string;
}

export type Relationship = "none" | "friend" | "outgoing" | "incoming";

export interface DirectoryUser extends User {
  relationship: Relationship;
  friendshipId: string | null;
  online: boolean;
}

export interface Friend extends User {
  friendshipId: string;
  unread: number;
  lastMessage: { body: string; at: string; senderId: string } | null;
}

export interface FriendRequest {
  id: string;
  createdAt: string;
  user: User;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  body: string;
  createdAt: string;
  deliveredAt: string | null;
  readAt: string | null;
  /** client-only flags for optimistic sends */
  pending?: boolean;
  failed?: boolean;
}

export type NotificationType = "friend_request" | "friend_accepted" | "missed_call";

export interface AppNotification {
  id: string;
  type: NotificationType;
  data: Record<string, unknown>;
  readAt: string | null;
  createdAt: string;
  actor: User | null;
}

export type CallType = "audio" | "video";

/** Shape of every socket.io acknowledgement from the server. */
export type Ack<T = Record<string, never>> =
  | ({ ok: true } & T)
  | { ok: false; error: string };
