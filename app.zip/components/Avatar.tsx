"use client";

const COLORS = ["#3B5BDB", "#0B7285", "#277A38", "#B25E09", "#A61E4D", "#6741D9", "#C92A2A", "#087F5B"];

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}

export default function Avatar({
  id,
  name,
  size = 40,
  online,
}: {
  id: string;
  name: string;
  size?: number;
  /** undefined hides the presence dot */
  online?: boolean;
}) {
  const initials =
    name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase() ?? "")
      .join("") || "?";
  return (
    <span className="avatar" style={{ width: size, height: size }}>
      <span
        className="avatar-circle"
        style={{ background: COLORS[hash(id) % COLORS.length], fontSize: size * 0.38 }}
      >
        {initials}
      </span>
      {online !== undefined && (
        <span
          className={`presence-dot ${online ? "is-online" : ""}`}
          title={online ? "Online" : "Offline"}
        />
      )}
    </span>
  );
}
