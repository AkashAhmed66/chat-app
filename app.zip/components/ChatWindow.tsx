"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";
import { formatTime } from "@/lib/format";
import type { Ack, ChatMessage, Friend } from "@/lib/types";
import { useAuth } from "./AuthProvider";
import Avatar from "./Avatar";
import { useCall } from "./CallProvider";
import { AlertIcon, ArrowLeftIcon, CheckCheckIcon, CheckIcon, ClockIcon, MessageIcon, PhoneIcon, SendIcon, VideoIcon } from "./Icons";
import { useRealtime } from "./RealtimeProvider";

interface HistoryResponse {
  messages: ChatMessage[];
  hasMore: boolean;
}

type SendAck = Ack<{ message: ChatMessage }>;

function Ticks({ m }: { m: ChatMessage }) {
  if (m.failed)
    return (
      <span className="tick tick-failed" title="Failed to send">
        <AlertIcon size={13} />
        Failed
      </span>
    );
  if (m.pending)
    return (
      <span className="tick" title="Sending">
        <ClockIcon size={13} />
      </span>
    );
  if (m.readAt)
    return (
      <span className="tick tick-read" title="Read">
        <CheckCheckIcon size={14} />
      </span>
    );
  if (m.deliveredAt)
    return (
      <span className="tick" title="Delivered">
        <CheckCheckIcon size={14} />
      </span>
    );
  return (
    <span className="tick" title="Sent">
      <CheckIcon size={14} />
    </span>
  );
}

/** Render with key={friend.id} so state resets when switching conversations. */
export default function ChatWindow({
  friend,
  onBack,
  onSent,
}: {
  friend: Friend;
  onBack: () => void;
  onSent: (message: ChatMessage) => void;
}) {
  const { user } = useAuth();
  const { socket, onlineIds, pushToast } = useRealtime();
  const { busy, startCall } = useCall();
  const online = onlineIds.has(friend.id);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [peerTyping, setPeerTyping] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);
  const tempCounter = useRef(0);
  const typingSent = useRef(false);
  const typingStopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const peerTypingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const markRead = useCallback(() => {
    if (!socket || document.hidden) return;
    socket.emit("message:read", { from: friend.id });
  }, [socket, friend.id]);

  // Initial history
  useEffect(() => {
    let cancelled = false;
    api<HistoryResponse>(`/api/messages/${friend.id}?limit=30`)
      .then((d) => {
        if (cancelled) return;
        setMessages(d.messages);
        setHasMore(d.hasMore);
        markRead();
      })
      .catch(() => pushToast("Could not load messages", "error"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [friend.id, markRead, pushToast]);

  // Mark as read again when the tab becomes visible.
  useEffect(() => {
    const onVisible = () => {
      if (!document.hidden) markRead();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [markRead]);

  // Real-time events for this conversation
  useEffect(() => {
    if (!socket) return;

    const onNew = (m: ChatMessage) => {
      if (m.senderId !== friend.id) return;
      stickToBottom.current = true;
      setMessages((prev) => (prev.some((p) => p.id === m.id) ? prev : [...prev, m]));
      setPeerTyping(false);
      markRead();
    };
    const onSelf = (m: ChatMessage) => {
      if (m.receiverId !== friend.id) return;
      stickToBottom.current = true;
      setMessages((prev) => (prev.some((p) => p.id === m.id) ? prev : [...prev, m]));
    };
    const onRead = ({ readerId, ids }: { readerId: string; ids: string[] }) => {
      if (readerId !== friend.id) return;
      const nowIso = new Date().toISOString();
      setMessages((prev) =>
        prev.map((m) => (ids.includes(m.id) ? { ...m, readAt: nowIso, deliveredAt: m.deliveredAt ?? nowIso } : m))
      );
    };
    const onDelivered = ({ receiverId, ids }: { receiverId: string; ids: string[] }) => {
      if (receiverId !== friend.id) return;
      const nowIso = new Date().toISOString();
      setMessages((prev) => prev.map((m) => (ids.includes(m.id) ? { ...m, deliveredAt: nowIso } : m)));
    };
    const onTyping = ({ userId, isTyping }: { userId: string; isTyping: boolean }) => {
      if (userId !== friend.id) return;
      setPeerTyping(isTyping);
      if (peerTypingTimer.current) clearTimeout(peerTypingTimer.current);
      // Safety net in case the "stopped typing" event is lost.
      if (isTyping) peerTypingTimer.current = setTimeout(() => setPeerTyping(false), 4000);
    };

    // After a reconnect we may have missed messages: reload the latest page.
    const onReconnect = () => {
      api<HistoryResponse>(`/api/messages/${friend.id}?limit=30`)
        .then((d) => {
          setMessages(d.messages);
          setHasMore(d.hasMore);
          markRead();
        })
        .catch(() => undefined);
    };

    socket.io.on("reconnect", onReconnect);
    socket.on("message:new", onNew);
    socket.on("message:self", onSelf);
    socket.on("message:read", onRead);
    socket.on("message:delivered", onDelivered);
    socket.on("typing", onTyping);
    return () => {
      socket.io.off("reconnect", onReconnect);
      socket.off("message:new", onNew);
      socket.off("message:self", onSelf);
      socket.off("message:read", onRead);
      socket.off("message:delivered", onDelivered);
      socket.off("typing", onTyping);
      if (peerTypingTimer.current) clearTimeout(peerTypingTimer.current);
      if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
    };
  }, [socket, friend.id, markRead]);

  useEffect(() => {
    if (stickToBottom.current) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, peerTyping]);

  async function loadOlder() {
    const oldest = messages.find((m) => !m.pending);
    if (!oldest) return;
    try {
      const d = await api<HistoryResponse>(
        `/api/messages/${friend.id}?limit=30&before=${oldest.id}`
      );
      stickToBottom.current = false;
      setMessages((prev) => [...d.messages, ...prev]);
      setHasMore(d.hasMore);
    } catch {
      pushToast("Could not load older messages", "error");
    }
  }

  function emitTyping(isTyping: boolean) {
    if (!socket || typingSent.current === isTyping) return;
    typingSent.current = isTyping;
    socket.emit("typing", { to: friend.id, isTyping });
  }

  function onChange(value: string) {
    setText(value);
    if (value.trim()) {
      emitTyping(true);
      if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
      typingStopTimer.current = setTimeout(() => emitTyping(false), 2000);
    } else {
      emitTyping(false);
    }
  }

  function send(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body || !socket || !user) return;

    const tempId = `tmp-${++tempCounter.current}`;
    const optimistic: ChatMessage = {
      id: tempId,
      senderId: user.id,
      receiverId: friend.id,
      body,
      createdAt: new Date().toISOString(),
      deliveredAt: null,
      readAt: null,
      pending: true,
    };
    stickToBottom.current = true;
    setMessages((prev) => [...prev, optimistic]);
    setText("");
    emitTyping(false);

    socket.emit("message:send", { to: friend.id, body }, (res: SendAck) => {
      setMessages((prev) =>
        res.ok
          ? prev.map((m) => (m.id === tempId ? res.message : m))
          : prev.map((m) => (m.id === tempId ? { ...m, pending: false, failed: true } : m))
      );
      if (res.ok) onSent(res.message);
      else pushToast(res.error, "error");
    });
  }

  const friendUser = { id: friend.id, username: friend.username, displayName: friend.displayName };

  return (
    <section className="chat-window">
      <header className="chat-header">
        <button className="icon-btn back-btn" onClick={onBack} aria-label="Back to conversations">
          <ArrowLeftIcon />
        </button>
        <Avatar id={friend.id} name={friend.displayName} online={online} />
        <div className="row-main">
          <strong className="truncate">{friend.displayName}</strong>
          <small className={`status-line ${peerTyping ? "is-typing" : online ? "is-online" : ""}`}>
            {peerTyping ? "typing..." : online ? "online" : "offline"}
          </small>
        </div>
        <div className="row-actions">
          <button
            className="icon-btn icon-btn-bordered"
            title={online ? "Audio call" : "User is offline"}
            aria-label="Audio call"
            disabled={busy || !online}
            onClick={() => startCall(friendUser, "audio")}
          >
            <PhoneIcon />
          </button>
          <button
            className="icon-btn icon-btn-bordered"
            title={online ? "Video call" : "User is offline"}
            aria-label="Video call"
            disabled={busy || !online}
            onClick={() => startCall(friendUser, "video")}
          >
            <VideoIcon />
          </button>
        </div>
      </header>

      <div className="messages">
        {hasMore && (
          <button className="link-btn center" onClick={loadOlder}>
            Load earlier messages
          </button>
        )}
        {loading && (
          <p className="empty-small" role="status">
            Loading...
          </p>
        )}
        {!loading && messages.length === 0 && (
          <div className="empty-state">
            <span className="empty-icon">
              <MessageIcon size={20} />
            </span>
            <strong>No messages yet</strong>
            <p>Send the first message to {friend.displayName}.</p>
          </div>
        )}
        {messages.map((m, i) => {
          const mine = m.senderId === user?.id;
          const groupStart = i === 0 || messages[i - 1].senderId !== m.senderId;
          return (
            <div
              key={m.id}
              className={`bubble-row ${mine ? "mine" : "theirs"} ${groupStart ? "group-start" : ""}`}
            >
              <div className={`bubble ${m.failed ? "bubble-failed" : ""}`}>
                <span className="bubble-text">{m.body}</span>
                <span className="bubble-meta">
                  {formatTime(m.createdAt)} {mine && <Ticks m={m} />}
                </span>
              </div>
            </div>
          );
        })}
        {peerTyping && (
          <div className="bubble-row theirs group-start" aria-label={`${friend.displayName} is typing`}>
            <div className="bubble typing-bubble">
              <span className="dot" />
              <span className="dot" />
              <span className="dot" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form className="composer" onSubmit={send}>
        <input
          value={text}
          onChange={(e) => onChange(e.target.value)}
          placeholder={`Message ${friend.displayName}`}
          aria-label="Message"
          maxLength={4000}
          autoComplete="off"
        />
        <button className="btn-primary btn-send" type="submit" disabled={!text.trim()} aria-label="Send message" title="Send">
          <SendIcon size={16} />
          <span className="btn-send-label">Send</span>
        </button>
      </form>
    </section>
  );
}
