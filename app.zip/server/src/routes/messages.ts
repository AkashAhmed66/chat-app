import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../auth";
import { pool } from "../db";
import { areFriends } from "../friends-util";
import { ah, HttpError, uuidSchema, validate } from "../utils";

const router = Router();
router.use(requireAuth);

const querySchema = z.object({
  before: z.string().regex(/^\d+$/).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional().default(30),
});

export const MESSAGE_COLUMNS = `
  id::text AS id, sender_id AS "senderId", receiver_id AS "receiverId", body,
  created_at AS "createdAt", delivered_at AS "deliveredAt", read_at AS "readAt"`;

/** Conversation history with one friend, paginated backwards by message id. */
router.get(
  "/:userId",
  ah(async (req, res) => {
    const me = req.user!.id;
    const other = validate(uuidSchema, req.params.userId);
    const { before, limit } = validate(querySchema, req.query);
    if (!(await areFriends(me, other))) throw new HttpError(403, "You can only chat with friends");

    const { rows } = await pool.query(
      `SELECT ${MESSAGE_COLUMNS} FROM messages
       WHERE LEAST(sender_id, receiver_id) = LEAST($1::uuid, $2::uuid)
         AND GREATEST(sender_id, receiver_id) = GREATEST($1::uuid, $2::uuid)
         AND ($3::bigint IS NULL OR id < $3::bigint)
       ORDER BY id DESC LIMIT $4`,
      [me, other, before ?? null, limit + 1]
    );
    res.json({ messages: rows.slice(0, limit).reverse(), hasMore: rows.length > limit });
  })
);

export default router;
