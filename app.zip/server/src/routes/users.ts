import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../auth";
import { pool } from "../db";
import { isOnline } from "../realtime";
import { ah, validate } from "../utils";

const router = Router();

const querySchema = z.object({
  q: z.string().trim().max(60).optional().default(""),
  limit: z.coerce.number().int().min(1).max(50).optional().default(30),
  offset: z.coerce.number().int().min(0).optional().default(0),
});

/** All users (except me) with their relationship to me; optional search by name/username. */
router.get(
  "/",
  requireAuth,
  ah(async (req, res) => {
    const me = req.user!.id;
    const { q, limit, offset } = validate(querySchema, req.query);
    const pattern = `%${q.replace(/[\\%_]/g, "\\$&")}%`;

    const { rows } = await pool.query(
      `SELECT u.id, u.username, u.display_name AS "displayName",
              f.id AS "friendshipId", f.status, f.requester_id AS "requesterId"
       FROM users u
       LEFT JOIN friendships f
         ON (f.requester_id = $1 AND f.addressee_id = u.id)
         OR (f.requester_id = u.id AND f.addressee_id = $1)
       WHERE u.id <> $1
         AND ($2::text = '' OR u.username ILIKE $3 OR u.display_name ILIKE $3)
       ORDER BY u.display_name ASC, u.id ASC
       LIMIT $4 OFFSET $5`,
      [me, q, pattern, limit + 1, offset]
    );

    const page = rows.slice(0, limit).map((r) => {
      let relationship: "none" | "friend" | "outgoing" | "incoming" = "none";
      if (r.status === "accepted") relationship = "friend";
      else if (r.status === "pending") relationship = r.requesterId === me ? "outgoing" : "incoming";
      return {
        id: r.id,
        username: r.username,
        displayName: r.displayName,
        relationship,
        friendshipId: r.friendshipId ?? null,
        online: isOnline(r.id),
      };
    });

    res.json({ users: page, hasMore: rows.length > limit });
  })
);

export default router;
